package Model;

public interface CopyStrategy {
	public void copy(PerspectiveModel source, PerspectiveModel destination);
}
